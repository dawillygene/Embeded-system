# LCDDisplay
Source code for the I2C 10 digit display based on BL55077

Micro-Python version [here](https://github.com/antigones/TC_LCDDisplay10_Arduino_micropy) courtesy of [Juna Salviati](https://github.com/antigones). Thank you Juna!
